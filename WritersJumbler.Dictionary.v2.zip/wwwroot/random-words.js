const ids=["az1","bz1","cz1","dz1","ez1","fz1","gz1","hz1","iz1","jz1","kz1","lz1","mz1","nz1","oz1","pz1","qz1","rz1","sz1","tz1","uz1","vz1","wz1","xz1","yz1","zz1","aaz1","abz1","acz1","adz1","aez1","afz1","agz1","ahz1","aiz1","ajz1","akz1","alz1","amz1","anz1","aoz1","apz1","aqz1","arz1","asz1","atz1","auz1","avz1","awz1","axz1"];
const cache={};
ids.forEach(id=>{const i=document.createElement('input');i.id=id;grid.appendChild(i)});
async function load(letter){if(cache[letter])return cache[letter];for(const name of [`api/dictionary-${letter}.json`,`api/dictionary-${letter.toLowerCase()}.json`]){try{const r=await fetch(name);if(!r.ok)continue;const d=await r.json();const words=Array.isArray(d)?d.map(x=>x.word||x.term||x.name).filter(Boolean):Object.keys(d);if(words.length)return cache[letter]=words}catch(e){}}return[]}
async function randomWord(){const abc='ABCDEFGHIJKLMNOPQRSTUVWXYZ';for(let tries=0;tries<52;tries++){const letter=abc[Math.floor(Math.random()*26)];const words=await load(letter);if(words.length)return words[Math.floor(Math.random()*words.length)]}return''}
async function fill(){newWords.disabled=true;for(const id of ids)document.getElementById(id).value=await randomWord();newWords.disabled=false}
newWords.onclick=fill;fill();
