Writers Jumbler + Open Dictionary

https://github.com/mhollingshead/open-dictionary

put api into wwwroot/api
